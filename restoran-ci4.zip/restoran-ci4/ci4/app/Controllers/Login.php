<?php namespace App\Controllers;

class Login extends BaseController
{
	public function index()
	{
		// return view('welcome_message');

		echo "<h1>Login<h1/>";
	}

	//--------------------------------------------------------------------

}
