<?php namespace App\Controllers\Admin;

use App\Controllers\BaseController;

class Menu extends BaseController
{
	public function index()
	{
		return view('welcome_message');
	}

	public function select()
	{
		echo "<h1>Untuk menampilkan data</h1>";
	}

	public function update($id = null, $nama = null)
	{
		echo "<h1>untuk update data dengan id : $id   $nama</h1>";
	}

	//--------------------------------------------------------------------

}
